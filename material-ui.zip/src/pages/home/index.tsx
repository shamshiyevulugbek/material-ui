import React from "react"
import { useForm, SubmitHandler} from "react-hook-form"


interface IFormInput {
  firstName: string
  lastName: string
  age: number
}

export const Home:React.FC = () => {
  const [ready,setReady] = React.useState<boolean>(false)
  const { watch,register, handleSubmit,formState:{errors} } = useForm<IFormInput>()
  const onSubmit: SubmitHandler<IFormInput> = (data) => console.log(data)
  console.log(errors,"errors")
  React.useEffect(() => {
    console.log("inside useEffect")
    const subscription = watch((data) =>{
      if(Object.values(data).every(v=>!!v)) setReady(true)
    }
    )
    return () => subscription.unsubscribe()
  }, [watch])
  return (
    <div>
      <form onSubmit={handleSubmit(onSubmit)}>
        <input {...register("firstName", { required: true, maxLength: 20,onChange:(e)=>console.log(e.target.value,"firstName") })} />
        <input {...register("lastName", {required:true, pattern: /^[A-Za-z]+$/i,onChange:(e)=>console.log(e.target.value,"lastName") })} />
        <input type="number" {...register("age", {required:true, min: 18, max: 99,onChange:(e)=>console.log(e.target.value,"age") })} />
        <input style={{backgroundColor:ready?"green":"grey"}} type="submit" />
      </form>
    </div>
  )
}
