import React from "react"
import { Container, Grid } from '@mui/material'
import { AuthBottom } from '../../components/authBottom'
import { ReactComponent as Image1 } from '../../assets/imges/login1.svg'

export const Signup:React.FC = () => {
  const [beforeInfo,setBeforeInfo] = React.useState<boolean>(true)
  return (
    <div>Signup</div>
  )
}
