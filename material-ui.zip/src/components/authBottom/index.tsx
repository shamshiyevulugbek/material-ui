import {Link} from 'react-router-dom'
import style from "./authBottom.module.scss"
export const AuthBottom = () => {
  return (
    <div className={style.authBottom}>
      <div className={style.links}>
        <Link to={"/"}>Пользовательское соглашение</Link>
        <Link to={"/"}>Лицензионное соглашение</Link>
        <Link to={"/"}>Проекты</Link>
        <Link to={"/"}>O’zbekcha</Link>
      </div>
      <p className={style.text}>
        All right reserved 2023
      </p>
    </div>
  )
}
