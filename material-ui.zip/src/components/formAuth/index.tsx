import React from 'react';
import style from './formAuth.module.scss';

import { ReactComponent as ReactLogo } from '../../assets/imges/logo.svg';

export const FormAuth = ({title=true,subtitle,children}:{title:boolean,subtitle:string,children:React.ReactNode}) => {

  return (
    <div className={style.formLogin}>
      <div className={style.logoContainer}>
        <ReactLogo className={style.logo} />
      </div>
      {title?<h3 className={style.heading}>WELCOME TO DWED</h3>:null}
      {<p className={style.text}>{subtitle}</p>}

      {children}
    </div>
  );
};
