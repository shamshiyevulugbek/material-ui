import {createTheme} from "@mui/material"
import {options} from "./mui-theme-options"

export const theme = createTheme(options)